<html xmlns="http://www.w3.org/1999/xhtml"> <!-- Bagian halaman HTML yang akan konvert -->  
<head>  
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
<!--
.style24 {color: #FF0000}
.style31 {font-weight: bold}
-->
</style>
<head>
<title>Cetak Data</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style5 {font-size: 34px}
.style6 {
	font-size: 21px;
	font-style: italic;
	font-weight: bold;
}
.style7 {font-size: 20px}
.style8 {font-size: 31px}
.style18 {font-size: 21px}
.style20 {font-size: 19px}
.style26 {
	font-size: 31px;
	color: #0000FF;
	font-weight: bold;
}
.style27 {font-size: 16px; color: #0000FF; }
.style28 {color: #0000FF; font-weight: bold; }
.style29 {font-weight: bold; font-size: 20px;}
.style30 {font-size: 21px; font-weight: bold; }
-->
</style>
</head>

<body onLoad="window.print()">
<p>&nbsp;</p>

<table width="980" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td>&nbsp;</td>
    <td colspan="8"><div align="center">
      <p class="style20">SURAT KETERANGAN
        UNTUK </p>
      <p class="style20">MENDAPATKAN PEMBAYARAN TUNJANGAN KELUARGA </p>
    </div></td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">1.Nama Lengkap </span></td>
    <td width="8"><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[npm]";?></span></td>
    <td width="47">&nbsp;</td>
    <td width="229">&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">1.Nama Lengkap </span></td>
    <td width="8"><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[npm]";?></span></td>
    <td width="47">&nbsp;</td>
    <td width="229">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">1.Nama Lengkap </span></td>
    <td width="8"><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[npm]";?></span></td>
    <td width="47">&nbsp;</td>
    <td width="229">&nbsp;</td>
  </tr>
  <tr>
    <td></td>
    <td colspan="8" class="style18">Saya yang bertanda tangan dibawah ini : : </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">1.Nama Lengkap </span></td>
    <td width="8"><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[npm]";?></span></td>
    <td width="47">&nbsp;</td>
    <td width="229">&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">2.NIP	</span></td>
    <td width="8"><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[nama]";?></span></td>
    <td width="47">&nbsp;</td>
    <td width="229">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">3.Tempat/tanggal lahir</span></td>
    <td><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[jurusan]";?></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">4.Jenis Kelamin </span></td>
    <td><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[no_hp]";?></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2"><span class="style18">5.Agama</span></td>
    <td><div align="center" class="style18">:</div></td>
    <td colspan="3"><span class="style18"><?php echo"$hasil[no_upload]";?></span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style18">6.Kebangsaan</td>
    <td class="style7">:</td>
    <td colspan="3" class="style7"><?php echo"$hasil[dosen1]";?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style7"><span class="style18">7.Pangkat/Golongan</span></td>
    <td class="style7">:</td>
    <td colspan="3" class="style7"><?php echo"$hasil[dosen2]";?></td>
    <td><span class="style18"></span></td>
    <td><span class="style18"></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style18">8.Jabatan struktural/fungsional</td>
    <td class="style7">:</td>
    <td colspan="3" class="style7"><?php echo"$hasil[dosen1]";?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style18">9.Pada Instansi, Dep/lemb</td>
    <td class="style7">:</td>
    <td colspan="3" class="style7"><?php echo"$hasil[dosen1]";?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
     <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style18">10.Masa kerja golongan	</td>
    <td class="style7">:</td>
    <td colspan="3" class="style7"><?php echo"$hasil[dosen1]";?></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style7">&nbsp;</td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td><span class="style18"></span></td>
    <td><span class="style18"></span></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style7">&nbsp;</td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td colspan="2"><div align="center"><span class="style18"></span></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="166" ><div align="left"></div></td>
    <td width="110" ><div align="center"></div></td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td colspan="2" rowspan="2"><div align="center"><span class="style18">Ketua Progam Studi,</span></div>      <div align="center"><span class="style18"></span></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td ><div align="left"></div></td>
    <td ><div align="center"></div></td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td ><div align="left"></div></td>
    <td ><div align="center"></div></td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td><span class="style18"></span></td>
    <td><span class="style18"></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td ><div align="right"></div></td>
    <td ><div align="center"></div></td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td><span class="style18"></span></td>
    <td><span class="style18"></span></td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td ><div align="right"></div></td>
    <td ><div align="center"></div></td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td><span class="style18"></span></td>
    <td><span class="style18"></span></td>
  </tr>
   <tr>
    <td>&nbsp;</td>
    <td colspan="2" class="style7">&nbsp;</td>
    <td class="style7">&nbsp;</td>
    <td colspan="3" class="style7">&nbsp;</td>
    <td colspan="2"><div align="center"><span class="style18"></span><span class="style18">
	<?php 
										if($hasil[jurusan]=='S-1 Sistem Informasi'){
											echo"SUYONO, M.T.I";
									} 
					 else { echo"RINA WATI, M.T.I"; 
					}
									
									?>
	
	</span></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="6" class="style7">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td class="style18">&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td class="style18">&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td class="style18">&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td colspan="2" rowspan="7" align="center" valign="top">&nbsp;</td>
    <td>&nbsp;</td>
    <td width="182" class="style7">&nbsp;</td>
    <td width="7" class="style18">&nbsp;</td>
    <td width="161" class="style7">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>















