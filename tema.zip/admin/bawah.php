<div class='footer'>
            <div class='no-gutters'>
                <div class='col-auto mx-auto'>
                    <div class='row no-gutters justify-content-center'>
                        <div class='col-auto'>
                            <a href='index.php?aksi=pasien' class='btn btn-link-default active'>
                                <i class='material-icons'>store_mall_directory</i>
                            </a>
                        </div>
                        <div class='col-auto'><?php if ($_SESSION['user'] === 'admin' || $_SESSION['id'] == 1) {
                            echo"
                            <a href='index.php?aksi=profil' class='btn btn-link-default'>
                                <i class='material-icons'>settings</i>
                            </a>";
                        } else {
                            echo"
                            <a href='index.php?aksi=pasien' class='btn btn-link-default'>
                                <i class='material-icons'>settings</i>
                            </a>";
                        } ?>
                        </div>
                        <div class='col-auto'>
                            <a href='index.php?aksi=home' class='btn btn-default shadow centerbutton'>
                                <i class='material-icons'>dashboard</i>
                            </a>
                        </div>
                        <div class='col-auto'>
                            <a href='index.php?aksi=admin' class='btn btn-link-default'>
                            <i class='material-icons'>account_circle</i>
                            </a>
                        </div>
                        <div class='col-auto'>
                            <a href='logout.php' class='btn btn-link-default'>
                                <i class='material-icons'>exit_to_app</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>