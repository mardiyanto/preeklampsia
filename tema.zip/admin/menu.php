<ul class="sidebar-menu">
  <li>
              <a href='index.php?aksi=home'>
                <i class='fa fa-dashboard'></i> <span>Dashboard</span> 
              </a> 
 </li>
 <?php if ($_SESSION['user'] === 'admin' || $_SESSION['id'] == 1) {
        // Izinkan akses ke semua data
        // Lakukan sesuatu dengan data
echo"

 <li>      
      <a href='index.php?aksi=profil'>
                  <i class='fa fa-briefcase'></i> <span>PROFIL</span>
                </a>
              </li>
<li class='treeview'>
               <a href='#'>
                 <i class='fa fa-bank'></i>
                 <span>MASTER DATA</span>
               </a>
               <ul class='treeview-menu'>
                <li><a href='index.php?aksi=pasien'><i class='fa fa-arrows-h'></i> Pasien</a></li>
                <li><a href='index.php?aksi=bmi'><i class='fa fa-arrows-h'></i> BMI</a></li>
                <li><a href='index.php?aksi=map'><i class='fa fa-arrows-h'></i> MAP</a></li>
                <li><a href='index.php?aksi=rot'><i class='fa fa-arrows-h'></i> ROT</a></li>

               </ul>
</li>
<li>      
      <a href='index.php?aksi=admin'>
                  <i class='fa fa-briefcase'></i> <span>Admin</span>
                </a>
              </li>
      <li> ";
    } else {

    }
?>     
      <a href="logout.php">
                  <i class="fa fa-sign-out"></i> <span>LOGOUT</span>
                </a>
              </li>
</ul>